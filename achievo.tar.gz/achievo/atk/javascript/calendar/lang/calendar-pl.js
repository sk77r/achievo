// ** I18N
Calendar._DN = new Array
("Niedziela",
 "Poniedzia�ek",
 "Wtorejk",
 "�roda",
 "Czwartek",
 "Pi�tek",
 "Sobota",
 "Niedziela");
Calendar._MN = new Array
("Stycze�",
 "Luty",
 "Marzec",
 "Kwiecie�",
 "Maj",
 "Czerwiec",
 "Lipiec",
 "Sierpie�",
 "Wrzesie�",
 "Pa�dziernik",
 "Listopad",
 "Grudzie�");

// tooltips
Calendar._TT = {};
Calendar._TT["TOGGLE"] = "Prze��cz pierwszy dzie� tygodnia";
Calendar._TT["PREV_YEAR"] = "Poprz. rok (przytrzymaj -> menu)";
Calendar._TT["PREV_MONTH"] = "Poprz. miesi�c (przytrzymaj -> menu)";
Calendar._TT["GO_TODAY"] = "Przejd� do dzisiejszej daty";
Calendar._TT["NEXT_MONTH"] = "Nast. miesi�c (przytrzymaj -> menu)";
Calendar._TT["NEXT_YEAR"] = "Nast. rok (przytrzymaj -> menu)";
Calendar._TT["SEL_DATE"] = "Wybierz dat�";
Calendar._TT["DRAG_TO_MOVE"] = "Przeci�gnij";
Calendar._TT["PART_TODAY"] = " (dzi�)";
Calendar._TT["MON_FIRST"] = "Poniedzia�ek jako pierwszy";
Calendar._TT["SUN_FIRST"] = "Niedziela jako pierwszy";
Calendar._TT["CLOSE"] = "Zamknij";
Calendar._TT["TODAY"] = "Dzi�";

// date formats
Calendar._TT["DEF_DATE_FORMAT"] = "y-mm-dd";
Calendar._TT["TT_DATE_FORMAT"] = "DD, d MM y";

Calendar._TT["WK"] = "tyg.";

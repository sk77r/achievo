// ** I18N
Calendar._DN = new Array
("Pazar",
 "Pazartesi",
 "Sal�",
 "�ar�amba",
 "Per�embe",
 "Cuma",
 "Cumartesi",
 "Pazar");
Calendar._MN = new Array
("Ocak",
 "�ubat",
 "Mart",
 "Nisan",
 "May�s",
 "Haziran",
 "Temmuz",
 "A�ustos",
 "Eyl�l",
 "Ekim",
 "Kas�m",
 "Aral�k");

// tooltips
Calendar._TT = {};
Calendar._TT["TOGGLE"] = "Haftan�n ilk g�n�n� de�i�tir";
Calendar._TT["PREV_YEAR"] = "�nceki y�l (men� i�in bas�l� tutun)";
Calendar._TT["PREV_MONTH"] = "�nceki ay (men� i�in bas�l� tutun)";
Calendar._TT["GO_TODAY"] = "Bug�ne git";
Calendar._TT["NEXT_MONTH"] = "Sonraki ay (men� i�in bas�l� tutun)";
Calendar._TT["NEXT_YEAR"] = "Sonraki y�l (men� i�in bas�l� tutun)";
Calendar._TT["SEL_DATE"] = "Tarih se�in";
Calendar._TT["DRAG_TO_MOVE"] = "Ta��mak i�in s�r�kleyin";
Calendar._TT["PART_TODAY"] = " (bug�n)";
Calendar._TT["MON_FIRST"] = "�lk g�n Pazartesi";
Calendar._TT["SUN_FIRST"] = "�lk g�n Sal�";
Calendar._TT["CLOSE"] = "Kapat";
Calendar._TT["TODAY"] = "Bug�n";

// date formats
Calendar._TT["DEF_DATE_FORMAT"] = "dd-mm-y";
Calendar._TT["TT_DATE_FORMAT"] = "d MM DD";

Calendar._TT["WK"] = "Hf";
